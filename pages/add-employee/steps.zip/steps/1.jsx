import EmployeeHeaderButtons from 'Components/Employee/EmployeeHeaderButtons';
import { useSelector } from 'react-redux';
import { findWhere } from 'underscore';
import router from 'next/router'


const Step1 = () => {
	const add_staff_clone = useSelector((state) => state.staff.add_staff_clone);

	const currentStep = 1;
	const currentInput = findWhere(add_staff_clone, { step: currentStep });

	const goToNextStep = (UpdatedData) => {
		console.log('Final UpdatedData', UpdatedData);
		// dispatch(updateInputByStep({ add_staff_clone, UpdatedData }));
		// if (currentStep < MAX_STEP) {
		// 	setCurrentStep(currentStep + 1);
		// } else {
		// 	console.log('FORM SUBMITTED');
		// }
	};
	return (
		<div>
			<div className="app-content content">
				<div className="content-overlay"> </div>
				<div className="header-navbar-shadow"> </div>
				<div className="content-wrapper">
					<div className="content-header row"> </div>
					<div className="content-body">
						<section>
							<EmployeeHeaderButtons title={currentInput?.title?.toLowerCase()} add_staff_clone={add_staff_clone} currentStep={currentStep} />
							<Step1 currentInput={currentInput} goToNextStep={goToNextStep} />
						</section>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Step1;
